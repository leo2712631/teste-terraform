#!/bin/bash

# Aplica as mudanças de infraestrutura
terraform apply -auto-approve

# Testa os recursos criados (exemplo para ALB)
ALB_DNS=$(terraform output alb_dns_name)
status=$(curl -s -o /dev/null -w "%{http_code}" http://"$ALB_DNS"/healthcheck)
if [ $status != 200 ]; then
  echo "Error: ALB healthcheck returned $status" 
  exit 1
fi

# Registra output em variável
terraform output my_instance_ip > /tmp/instance_ip