#!/bin/bash

# Instala o Terraform
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://rpm.releases.hashicorp.com/AmazonLinux/hashicorp.repo
sudo yum -y install terraform

# Faz checkout do código Terraform do S3 
aws s3 cp s3://meu-bucket/main.tf .
aws s3 cp s3://meu-bucket/variables.tf . 

# Inicializa o diretório Terraform
terraform init